package gymsystem;

import javafx.application.Application;
import javafx.stage.Stage;
import java.util.Scanner;

public class MyGymManager extends Application {
    public static String sort;

    @Override
    public void start(Stage primaryStage) throws Exception {
        while (true){
            sort = "no";
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Instructions");
        System.out.println("A - add a new member");
        System.out.println("X - delete a member");
        System.out.println("R - sort the member list");
        System.out.println("P - print the member list");
        System.out.println("S - save the member list");
        System.out.println("T - open the saved file");
        System.out.println("G - open GUI");

        while (true) {
            String answer = scanner1.nextLine();

            if (answer.equals("A")) {
                AddNewMember.addNewMember();    //new adding
                break;

            } else if (answer.equals("X")) {
                DeleteMember.delete();         //Deleting a member
                break;

            } else if (answer.equals("R")) {
                break;                         //Sorting the member list

            } else if (answer.equals("P")) {
                Print.PrintList();            //printing the member list
                break;

            } else if (answer.equals("S")) {
                sort = "yes";                   //saving the member list
                break;

            } else if (answer.equals("T")) {
                break;                       //open the saved the member list

            } else if (answer.equals("G")) {
                break;                         //open the GUI

            } else {
                System.out.println("Invalid Input");

                }


            }


        }
    }
}
