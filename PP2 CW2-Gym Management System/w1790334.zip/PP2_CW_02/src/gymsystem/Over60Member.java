package gymsystem;

import javax.naming.InvalidNameException;
import java.util.Arrays;
import java.util.Collection;

//over 60 members

public class Over60Member {
    private static String Age ;

    public static void setAge(String age) throws InvalidNameException {

        char[] chars = age.toCharArray();
        Collection<Character> uniqueCharacters = Arrays.asList(' ');

        for (char char1 : chars) {

            //letter or space...

            if (Character.isLetter(char1) || uniqueCharacters.contains(char1)) {
                Age = age;

            } else {
                throw new InvalidNameException();
            }

        }

    }

    public static String getAge(){
        return Age;
    }
}

