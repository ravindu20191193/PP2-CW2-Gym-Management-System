package gymsystem;

import javax.naming.InvalidNameException;
import java.util.Arrays;
import java.util.Collection;

//student member

public class StudentMember {
    private static String SchoolName;

    public static void setName(String sclName) throws InvalidNameException {
    char[] chars = sclName.toCharArray();

    Collection<Character> uniqueCharacters = Arrays.asList(' ');

        for (char char1 : chars) {

        //letter or space...

        if (Character.isLetter(char1) || uniqueCharacters.contains(char1)) {
            SchoolName = sclName;

        } else {
                throw new InvalidNameException();
            }

        }
    }

public static String getName(){return SchoolName;}
}

