package gymsystem;

import java.util.Arrays;
import java.util.Collection;

class notInRange extends Exception{
}

class InvalidNameException extends Exception{
}

public class DefaultMember {
    private static String MemberID;
    private static String Name;

    //Checking the membership number length

    public static void setMemberID(String memberid) throws Exception {
        if (memberid.length() == 5) {
            MemberID = memberid;
        } else {
            throw new notInRange();
        }
    }

    public static String getMemberID() {return MemberID;};

    //Checking the Name

    public static void setName(String name) throws Exception {
        char[] chars = name.toCharArray();
        Collection<Character> uniqueCharacters = Arrays.asList(' ');
        for (char char1 : chars) {

            //Here the if condition is for; if character is a letter or a space the name get set to the Member name variable.

            if (Character.isLetter(char1) || uniqueCharacters.contains(char1)) {
                Name = name;
            } else{
                throw new InvalidNameException();
        }

    }

}
    public static String getName(){
        return Name;
    }

}
