package gymsystem;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import javax.naming.InvalidNameException;
import java.util.Scanner;

//Adding student members

public class AddStudentMember {

    public static void addStudentMember() {

        //School name is unique for this class

        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Type School Name of the Member");

        while (true) {
            try {

                String name1 = scanner1.nextLine();
                StudentMember.setName(name1);
                SetDataBase.setDB();

                DBCollection table1 = SetDataBase.database.getCollection("Members");
                BasicDBObject basicDBObject = new BasicDBObject();

                AddDefaultMember.basicDBObject.put("SchoolName", StudentMember.getName());
                System.out.println("You have successfully entered the data");
                break;

            } catch (InvalidNameException exception) {
                System.out.println("Member Name is not in valid");


            }
        }
    }
}
