package gymsystem;
import com.mongodb.MongoClient;
import com.mongodb.DB;

//Linking the database to program

public class SetDataBase {
    public static DB database;
    //local host
    public static MongoClient mongoClient= new MongoClient("localhost",27017);

    public static void setDB(){
        //
        database = mongoClient.getDB("Gym");
        database.createCollection("MemberDetails",null);
    }
}
