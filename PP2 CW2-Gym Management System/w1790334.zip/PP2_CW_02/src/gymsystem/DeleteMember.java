package gymsystem;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.util.Scanner;

//Deleting a member

public class DeleteMember {
    public static Boolean TakenID;
    public static void delete() {

        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Type ID of the Member to delete");

                //First we set the existing ID to false.

        while (true) {
            try {

                //When it gets false method will run

                TakenID = false;

                String memberid = scanner1.nextLine();
                DefaultMember.setMemberID(memberid);
                SetDataBase.setDB();

                DBCollection table1 = SetDataBase.database.getCollection("Members");
                DBCursor findIterable = table1.find();

                for (DBObject totalCount : findIterable) {
                    String dataBaseID = (String) totalCount.get("Membership Number");
                    String selectedID = DefaultMember.getMemberID();

                    if (dataBaseID.equals(selectedID)) {
                        TakenID = true;
                        break;
                    }
                }

                if (TakenID) {
                    BasicDBObject basicDBObject = new BasicDBObject();
                    basicDBObject.put("Membership Number", DefaultMember.getMemberID());
                    table1.findAndRemove(basicDBObject);
                    System.out.println("Data successfully deleted");
                } else {

                    System.out.println("Input a valid Membership Number");
                    break;

                }

            } catch (notInRange exception) {
                System.out.println("MemberID is not in Range");

            }catch (Exception r) {
                r.printStackTrace();

            }
        }
    }
}
