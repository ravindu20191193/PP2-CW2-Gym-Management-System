package gymsystem;
import com.mongodb.MongoClient;
import com.mongodb.DB;

public class DataBaseLink {
    public static DB database;
    //local host
    public static MongoClient mongoClient= new MongoClient("localhost",27017);

    public static void setDB(){

        //Creating the database

        database = mongoClient.getDB("Gym");
        database.createCollection("MemberDetails",null);
    }
}
