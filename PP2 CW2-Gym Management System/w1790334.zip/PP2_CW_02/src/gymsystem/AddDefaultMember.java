package gymsystem;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.util.Scanner;

// Adding a new default member

public class AddDefaultMember {
    public static Boolean TakenID;
    public static BasicDBObject basicDBObject = new BasicDBObject();
    public static void addDefaultMember() throws Exception {

        basicDBObject.clear();
        Scanner scanner1 = new Scanner(System.in);

        //Inserting the member ID s

        System.out.println("Type ID of the Member");

        while (true) {
            try {
                TakenID=false;

                String memberid = scanner1.nextLine();
                DefaultMember.setMemberID(memberid);
                SetDataBase.setDB();

                DBCollection table1 = SetDataBase.database.getCollection("Members");
                DBCursor findIterable = table1.find();
                for (DBObject totalCount : findIterable) {

                    String dataBaseID = (String) totalCount.get("Membership Number");
                    String selectedID = DefaultMember.getMemberID();
                    if (selectedID.equals(dataBaseID)) {
                        TakenID = true;
                        break;
                    }
                }

                if (TakenID){
                    System.out.println("ID already taken,please try another.");

                }else {
                    basicDBObject.put("Membership Number", DefaultMember.getMemberID());
                    System.out.println("You have successfully entered the data");
                    break;
                }

            }catch (notInRange exception){
                System.out.println("MemberID is not in Range");
            }
        }

        //Inserting the member names

        System.out.println("Type Name of the Member");

        while (true) {
            try {
                String name = scanner1.nextLine();
                DefaultMember.setName(name);
                SetDataBase.setDB();

                DBCollection table1 = SetDataBase.database.getCollection("Members");
                basicDBObject.put("Member Name", DefaultMember.getName());
                System.out.println("You have successfully entered the data");
                break;

            } catch (notInRange exception) {
                System.out.println("Member Name is not valid");


            }
        }

    }

}