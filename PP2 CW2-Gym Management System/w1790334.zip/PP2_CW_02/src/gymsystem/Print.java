package gymsystem;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

//Print the member list with all details

public class Print {
    public static DBCursor counter1;
    public static void PrintList(){

        BasicDBObject basicDBObject= new BasicDBObject("Name",1);
        SetDataBase.setDB();

        DBCollection table1 = SetDataBase.database.getCollection("Members");

        if (MyGymManager.sort.equals("yes")) {
            counter1 = table1.find().sort(basicDBObject);

        }else{
            counter1 = table1.find();

        }for (DBObject totalCount : counter1) {

            String MemberID = (String) totalCount.get("Membership Number");
            String name= (String) totalCount.get("Member Name");
            String category= (String) totalCount.get("Category");
            String SchoolName= (String) totalCount.get("SchoolName");
            String Age=(String)totalCount.get("Age");

            System.out.println("MemberID "+MemberID);
            System.out.println("Name "+name);
            System.out.println("Category "+category);

            //Since school name and age are unique for relevant classes,

            if (category.equals("Student")){
                System.out.println("SchoolName: "+SchoolName);

            }if (category.equals("Over60Member")){
                System.out.println("Age: "+Age);
            }

        }
    }
}
