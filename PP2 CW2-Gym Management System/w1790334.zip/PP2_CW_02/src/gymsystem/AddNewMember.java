package gymsystem;

import com.mongodb.DBCollection;
import java.util.Scanner;

public class AddNewMember {
    public static void addNewMember() throws Exception{

        Scanner scanner1= new Scanner(System.in);

        //Instructions

        System.out.println("Choose the member category");
        System.out.println("To choose default member, type as 'default'");
        System.out.println("To choose student member, type as 'student'");
        System.out.println("To choose over 60 member, type as 'over60'");

        while (true){
            String input = scanner1.nextLine();
            SetDataBase.setDB();
            DBCollection table1 = SetDataBase.database.getCollection("Members");

            // default member detail method

            if (input.equals("default")){
                AddDefaultMember.addDefaultMember();
                AddDefaultMember.basicDBObject.put("Category","default");
                table1.insert(AddDefaultMember.basicDBObject);
                break;

                // default member detail method + student member detail method

            }else if (input.equals("student")){
                AddDefaultMember.addDefaultMember();
                AddStudentMember.addStudentMember();
                AddDefaultMember.basicDBObject.put("Category","student");
                table1.insert(AddDefaultMember.basicDBObject);
                break;

            }else if (input.equals("over60")){

                AddDefaultMember.addDefaultMember();
                AddOver60Member.addOver60Member();
                AddDefaultMember.basicDBObject.put("Category","over60");
                table1.insert(AddDefaultMember.basicDBObject);

                // default member detail method + over60 member detail method
                 break;
            }else{
               System.out.println("Invalid Input");
            }

        }

    }

}
