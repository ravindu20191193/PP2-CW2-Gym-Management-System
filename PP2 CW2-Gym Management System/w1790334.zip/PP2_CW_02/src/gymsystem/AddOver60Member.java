package gymsystem;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import javax.naming.InvalidNameException;
import java.util.Scanner;

//Adding over 60 members

public class AddOver60Member {
    public static void addOver60Member() {

        //Age is unique for this class

        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Type Age of the Member");

        while (true) {
            try {

                String name1 = scanner1.nextLine();
                Over60Member.setAge(name1);
                SetDataBase.setDB();

                DBCollection table1 = SetDataBase.database.getCollection("Members");
                BasicDBObject basicDBObject = new BasicDBObject();
                AddDefaultMember.basicDBObject.put("Age", Over60Member.getAge());

                System.out.println("You have successfully entered the data");
                break;

            } catch (InvalidNameException exception) {
                System.out.println("Member Age is not in valid");


            }
        }
    }
}
